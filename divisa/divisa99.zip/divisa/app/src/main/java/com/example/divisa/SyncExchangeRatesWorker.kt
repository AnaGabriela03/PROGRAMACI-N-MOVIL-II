package com.example.divisa

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SyncExchangeRatesWorker(context: Context, workerParams: WorkerParameters) : Worker(context, workerParams) {

    override fun doWork(): Result {
        val apiService = RetrofitClient.getApiService()
        val call = apiService.getExchangeRate()

        var result = Result.failure()

        call.enqueue(object : Callback<ExchangeResponse> {
            override fun onResponse(call: Call<ExchangeResponse>, response: Response<ExchangeResponse>) {
                if (response.isSuccessful) {
                    val exchangeResponse = response.body()
                    val ratesMap = exchangeResponse?.rates ?: emptyMap()

                    // Obtener la última hora de actualización
                    val dbHelper = ExchangeRateDbHelper(applicationContext)
                    val lastUpdateTime = dbHelper.getLastUpdateTime()

                    // Guardar los resultados en la base de datos solo si es válido
                    dbHelper.insertRatesIfValid(ratesMap, lastUpdateTime)

                    result = Result.success()
                } else {
                    result = Result.retry()  // Intentar de nuevo si ocurre un error
                }
            }

            override fun onFailure(call: Call<ExchangeResponse>, t: Throwable) {
                result = Result.retry()
            }
        })

        return result
    }
}

